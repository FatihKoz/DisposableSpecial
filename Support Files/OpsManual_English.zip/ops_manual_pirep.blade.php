<div class="row">
  <div class="col-md-8">
    <div class="card mb-2">
      <div class="card-header p-1">
        <h5 class="m-1">Starting A Flight, Pausing and Reporting</h5>
      </div>
      <div class="card-body p-1">
        After you load your flight with procedures explained in other tabs;
        <ul>
          <li>Be sure your sim is running and aircraft is ready at departure airport on a parking stand</li>
          <li>Be sure your engines are NOT running (idle n2 / no fuel flow)</li>
          <li>Be sure your Parking Brakes are SET (usage of chocks are not recognized by acars !)</li>
        </ul>
        <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
          <li class="nav-item" role="presentation">
            <a class="nav-link mx-1 p-1 active" id="pills-finfo-tab" data-toggle="pill" href="#pills-finfo" role="tab" aria-controls="pills-finfo" aria-selected="true">
              Acars / Flight Info screen
            </a>
          </li>
          <li class="nav-item" role="presentation">
            <a class="nav-link mx-1 p-1" id="pills-flight-tab" data-toggle="pill" href="#pills-flight" role="tab" aria-controls="pills-flight" aria-selected="false">
              During Flight
            </a>
          </li>
          <li class="nav-item" role="presentation">
            <a class="nav-link mx-1 p-1" id="pills-alanding-tab" data-toggle="pill" href="#pills-alanding" role="tab" aria-controls="pills-alanding" aria-selected="false">
              After Landing
            </a>
          </li>
          <li class="nav-item" role="presentation">
            <a class="nav-link mx-1 p-1" id="pills-parked-tab" data-toggle="pill" href="#pills-parked" role="tab" aria-controls="pills-parked" aria-selected="false">
              Sending the Report
            </a>
          </li>
        </ul>
        <div class="tab-content" id="pills-tabContent">
          <div class="tab-pane fade show active" id="pills-finfo" role="tabpanel" aria-labelledby="pills-finfo-tab">
            <ul>
              <li>Check <b>Flight Type</b> and correct if necessary</li>
              <li>(For Tour flights) double check Code ve Leg fields and correct if necessary</li>
              <li>Check aircraft selection, payload distribution according to your flight plan and performance calculations (ammend if required)</li>
              <li>Click <b>"Start Flight"</b> button</li>
            </ul>
          </div>
          <div class="tab-pane fade" id="pills-flight" role="tabpanel" aria-labelledby="pills-flight-tab">
            <ul>
              <li>Be sure you are connected to internet during the flight (*)</li>
              <li>Check acars map screen time to time to see if there are any errors reported, also note any repeating errors (*)</li>
            </ul>
          </div>
          <div class="tab-pane fade" id="pills-alanding" role="tabpanel" aria-labelledby="pills-alanding-tab">
            <ul>
              <li>Leave the runway and park at a suitable spot</li>
              <li>Be sure your Parking Brakes are SET (usage of chocks are not recognized by acars !)</li>
              <li>Be sure your engines are NOT running (idle n2 / no fuel flow)</li>
              <li>At this point (without waiting de-boarding) you can click <b>"End Flight"</b> button to finish your flight</li>
            </ul>
          </div>
          <div class="tab-pane fade" id="pills-parked" role="tabpanel" aria-labelledby="pills-parked-tab">
            <ul>
              <li>A brief summary will be displayed at Acars/Flight Summary screen, click <b>"File Pirep"</b> button to send in your report</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="card mb-1">
      <div class="card-body p-1">
        In cases where you feel continuation of the flight is not possible but you do not want to loose the progress by cancelling;
        <ul>
          <li>If you are flying online (and if any available ATC is present, inform the ATCO) disconnect from the server</li>
          <li>PAUSE your simulator</li>
          <li>If available save the flight or the state of your aircraft</li>
          <li>Note down your load and current fuel figures</li>
          <li>Note down your current location</li>
          <li>Close acars</li>
          <li>Close simulator</li>
        </ul>
        When you are ready to proceed;
        <ul>
          <li>Run your simulator, place your aircraft to the closest possible location you noted, check your fuel/load values and adjust them to match prev figures</li>
          <li>PAUSE your simulator</li>
          <li>Run acars</li>
          <li>Acars will recognize your previous unfinished flight and ask about your intentions</li>
          <li>Select RESUME</li>
          <li>Once you see your flight and aircraft details at Acars / Map screen, UN-PAUSE your sim and continue flight</li>
        </ul>
      </div>
    </div>
    <div class="card mb-1">
      <div class="card-body p-1">
        <ul>
          <li>You can cancel a fligt anytime you wish</li>
          <li>You can use PAUSE function of your sim whenever you need to (except IVAO/VATSIM online flights)</li>
          <li>The <b>aircraft icon</b> visible on Acars menu bar acts as <b>Start Flight, Cancel Flight, End Flight</b> buttons according to flight phase</li>
          <li>(*) In any case where no data is transferred within <b>{{ @setting('acars_live_time') }} hours</b> during a flight (except PAUSE) your active flight/pirep will be <b>deleted !</b></li>
        </ul>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card-body p-0">
      {{-- Intentionally Left Blank --}}
    </div>
  </div>
</div>
<div class="row">
  <div class="col-md-8">
    <div class="card mb-1">
      <div class="card-header p-1">
        <h5 class="m-1">Defined Flights (Schedules, Tours etc.)</h5>
      </div>
      <div class="card-body p-1">
        <p>
          We do have some pre-defined flights for you to enjoy, they may be changed and/or updated over the time, it is always possible to pick one and fly.
          According to our rules, you may be limited to fly out only from your current location <b>(*)</b>,
          if this is the case all flight related functions like acars and web search, bids etc will be filtered out automatically by the system.
        </p>
      </div>
    </div>
    <div class="card mb-1">
      <div class="card-body p-1">
        <b>If you wish to proceed with web services;</b>
        <ul>
          <li>Click <b>"Flight Operations"</b> and <b>"Flights"</b> buttons from main menu</li>
          <li>All available flights will be listed</li>
          <li>If you wish you can use the search module to filter down the results</li>
          <li>When you decide on the flight to execute...</li>
        </ul>
        <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
          <li class="nav-item" role="presentation">
            <a class="nav-link mx-1 p-1 active" id="pills-sb-tab" data-toggle="pill" href="#pills-sb" role="tab" aria-controls="pills-sb" aria-selected="true">
              Continue with SimBrief flight planning
            </a>
          </li>
          <li class="nav-item" role="presentation">
            <a class="nav-link mx-1 p-1" id="pills-nonsb-tab" data-toggle="pill" href="#pills-nonsb" role="tab" aria-controls="pills-nonsb" aria-selected="false">
              Continue without planning</a>
          </li>
        </ul>
        <div class="tab-content" id="pills-tabContent">
          <div class="tab-pane fade show active" id="pills-sb" role="tabpanel" aria-labelledby="pills-sb-tab">
            <ul>
              <li>Click <b>"Generate SimBrief OFP"</b> button/icon (Proceed with aircraft selection and flight planning)</li>
              <li>When you reach SimBrief Briefing page, do check your flight plan (edit if necessary) and click <b>"Load in Acars"</b> button</li>
              <li>Acars will run and your flight will be loaded with full details (including your SimBrief OFP)</li>
            </ul>
          </div>
          <div class="tab-pane fade" id="pills-nonsb" role="tabpanel" aria-labelledby="pills-nonsb-tab">
            <ul>
              <li>Click <b>"Load in Acars"</b> button/icon</li>
              <li>Acars will run and your flight will be loaded with basic details</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="card mb-1">
      <div class="card-body p-1">
        <b>If you wish to leave web and proceed with Acars;</b>
        <ul>
          <li>Run acars</li>
          <li>Click on <b>"Flight Search/Bid"</b> (A) icon</li>
          <li>If you have a bid, it will be listed first, if not the screen will be empty</li>
          <li>Click on <b>"Find Flights"</b> (B) button (if you wish you can use dep/arr ICAO code fields to filter down your search)</li>
          <li>Select the flight you want to execute and click it's <b>"Load"</b> (C) button</li>
        </ul>
      </div>
    </div>
    <div class="card mb-1">
      <div class="card-body p-1">
        <p>
          If you wish you can use/visit <b>Flight Details</b> page for above mentioned web tasks, all necessary buttons and functions are also present there. At that page you will have
          full details like route map, departure and arrival weather and even sunrise sunset details of those airports.
        </p>
        <p>You can use <b>Tours</b> module to reach the <b>Flight Details</b> page too, either the map or the legs list will lead you to that same page.</p>
        <p>
          <b>(*)</b> If this is the case you can always use <b>JumpSeat Travel</b> module to transfer yourself between airports. 
          Please do check the flight and aircraft availabilities for your intended new location before going there. 
          We have no refund policy for JumpSeat ticket fees :)
        </p>
        <p>Please proceed to Starting / Reporting flights section ...</p>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card-body p-0">
      <img class="img-fluid rounded border border-dark" alt="" src="{{ public_asset('/image/acars/schedule_01.png') }}"/>
    </div>
    <hr>
    <div class="card-body p-0">
      <img class="img-fluid rounded border border-dark" alt="" src="{{ public_asset('/image/acars/schedule_02.png') }}"/>
    </div>
    <hr>
    <div class="card-body p-0">
      <img class="img-fluid rounded border border-dark" alt="" src="{{ public_asset('/image/acars/schedule_03.png') }}"/>
    </div>
  </div>
</div>
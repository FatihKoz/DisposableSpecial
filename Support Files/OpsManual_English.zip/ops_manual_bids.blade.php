<div class="row">
  <div class="col-md-8">
    <div class="card mb-2">
      <div class="card-header p-1">
        <h5 class="m-1">Flight Bids</h5>
      </div>
      <div class="card-body p-1">
        <p>It is possible to bid on any pre-defined flight</p>
        <ul>
          <li>Click <b>"Add/Remove Bid"</b> button/icon</li>
          <li>According to current state either your bid will be added or removed, page will refresh</li>
          <li>If you want to see your bids later on you can use <b>"My Bids"</b> links anytime you wish</li>
          <li>You need to start a bidded flight within <b>{{ @setting('bids.expire_time') }} hours</b>, otherwise your bid will be deleted automatically</li>
        </ul>
      </div>
    </div>
    <div class="card mb-1">
      <div class="card-body p-1">
        <p>
          Other procedures for bidded flights (like SimBrief generation, Loading in Acars, Searching) are same for pre-defined flights, 
          so if you need please check other tabs for more details.
        </p>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card-body p-0">
      <img class="img-fluid rounded border border-dark" src="{{ public_asset('/image/acars/bids_01.png') }}" alt=""/>
    </div>
  </div>
</div>